//
//  Shape.cpp
//  MacGraphicsStarter
//
//  Created by Cody Brown on 10/27/14.
//
//

#include "Shape.h"
Shape::Shape(double red, double green, double blue)
{
    Mred = red;
    Mblue = blue;
    Mgreen = green;
    

}

