//
//  maze.cpp
//  MacGraphicsStarter
//
//  Created by Cody Brown on 2/3/15.
//
//

#include "maze.h"

using namespace std;
int counter=0;
Maze::Maze()
{
    srand(time(0));
    removeWalls(0, 0);
    mCell[0][0].mBottom = false;
    mCell[COL-1][ROW-1].mTop = false;
}

Maze::Cell::Cell()
{
    mTop = mBottom = mLeft = mRight = true;
    mVisited = false;
    num = '0';
}

void Maze::draw()
{
    for (int i=0; i<=COL; i++)
    {
        for (int j=0; j<ROW; j++)
        {
            mCell[i][j].draw(i, j);
        }
    }
}



void Maze::removeWalls(int x, int y)
{
    mCell[x][y].mVisited = true;
    vector<char> moves;
    int random;
    while (true)
    {
        moves.clear();
        if (y > 0 && !mCell[x][y-1].mVisited)//down
        {
           moves.push_back('d');
           
        }
        if (y < COL-1 && !mCell[x][y+1].mVisited)//up
        {
            moves.push_back('u');
        }
        if (x > 0 && !mCell[x-1][y].mVisited)//left
        {
            moves.push_back('l');
        }
        if (x < ROW-1 && !mCell[x+1][y].mVisited)//right
        {
            moves.push_back('r');
        }
        if (moves.size()>0)
        {
           /*
            counter++;                // number to be converted to a string
            string Result;            // string which will contain the result
            ostringstream convert;    // stream used for the conversion
            convert << counter;       // insert the textual representation of 'Number' in the characters in the stream
            result = convert.str();   // stores converted string in result
            mCell[x][y].num = result; // stores result in data member num
            */
            random = rand() % moves.size();
            if (moves[random] == 'd')
            {
                mCell[x][y].mBottom = false;
                mCell[x][y-1].mTop = false;
                removeWalls(x, y-1);
            }
            if (moves[random] == 'u')
            {
                mCell[x][y].mTop = false;
                mCell[x][y+1].mBottom = false;
                removeWalls(x, y+1);
            }
            if (moves[random] == 'l')
            {
                mCell[x][y].mLeft = false;
                mCell[x-1][y].mRight = false;
                removeWalls(x-1, y);
            }
            if (moves[random] == 'r')
            {
                mCell[x][y].mRight = false;
                mCell[x+1][y].mLeft = false;
                removeWalls(x+1, y);
            }
        }
        else
        {
            break;
        }
    }
}

void Maze::Cell::draw(int x, int y)
{
    glBegin(GL_LINES);
    glColor3d(0,0,1);
    if (mBottom)
    {
        glVertex2d(x, y);
        glVertex2d(x+1, y);
    }
    if (mLeft)
    {
        glVertex2d(x, y);
        glVertex2d(x, y+1);
    }
    if (mTop)
    {
        glVertex2d(x, y+1);
        glVertex2d(x+1, y+1);
    }
    if (mRight)
    {
        glVertex2d(x+1, y);
        glVertex2d(x+1, y+1);
    }
    
    glEnd();
}
